package com.company.bowlingGame;

public class Game {
    // keep track of rolls
    public void roll(int pins) {
    }

    // calculate score
    public int score() {
        return 0;
    }
}