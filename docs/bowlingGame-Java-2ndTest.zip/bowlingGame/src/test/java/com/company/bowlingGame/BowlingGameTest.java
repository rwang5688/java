package com.company.bowlingGame;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

class BowlingGameTest {
    private Game g;

    // remove Game creation duplicate
    @BeforeEach
    protected void setUp() throws Exception {
        g = new Game();
    }

    // 1st Test
    @Test
    public void testGutterGame() throws Exception {
        for (int i = 0; i < 20; i++) {
            g.roll(0);
        }
        assertEquals(0, g.score());
    }

    // 2nd Test
    @Test
    public void testAllOnes() throws Exception {
        for (int i = 0; i < 20; i++) {
            g.roll(1);
        }
        assertEquals(20, g.score());
    }
}
