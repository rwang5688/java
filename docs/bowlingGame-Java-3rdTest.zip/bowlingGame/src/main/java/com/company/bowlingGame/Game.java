package com.company.bowlingGame;

public class Game {
    private int score_ = 0;

    // accumulate  score
    public void roll(int pins) {
        score_ += pins;
    }

    // return score
    public int score() {
        return score_;
    }
}